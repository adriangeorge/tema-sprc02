package database

import (
	// Go packages
	"context"
	"fmt"
	"log"
	"os"
	"service/models"

	// Models

	// Mongo packages

	"github.com/go-playground/validator/v10"
	"go.mongodb.org/mongo-driver/bson"
	"go.mongodb.org/mongo-driver/mongo"
	"go.mongodb.org/mongo-driver/mongo/options"
	"go.mongodb.org/mongo-driver/x/bsonx"
)

var DB *mongo.Database
var TaraCollection *mongo.Collection
var OraseCollection *mongo.Collection
var TemperaturiCollection *mongo.Collection
var CountersCollection *mongo.Collection
var Context context.Context
var Validator = validator.New()

func IndexQuery(target_coll string, reserve bool) (int, error) {
	// Check if this operation wants to assign a new ID or it's releasing it
	// after a bad operation attempt
	isReserving := 1
	if !reserve {
		isReserving = 0
	}
	// Retrieve new object's id
	counter_filter := bson.D{{}}
	update := bson.D{{Key: "$inc", Value: bson.D{{Key: target_coll, Value: isReserving}}}}
	res := CountersCollection.FindOneAndUpdate(Context, counter_filter, update)
	if res == nil {
		fmt.Println("ERROR RESERVE INDEX")
	}
	var counters models.ID_COUNTERS
	res.Decode(&counters)

	if target_coll == "id_tari" {
		return counters.Id_tari, nil
	} else if target_coll == "id_orase" {
		return counters.Id_orase, nil
	} else if target_coll == "id_temperaturi" {
		return counters.Id_temperaturi, nil
	} else {
		return -1, fmt.Errorf("invalid id target")
	}
}

func InitDatabase() {
	// Create collection
	command := bson.D{{Key: "create", Value: "Tari"}}
	var result bson.M
	if err := DB.RunCommand(Context, command).Decode(&result); err != nil {
		log.Fatal(err)
	}

	// Create unique
	TaraCollection = DB.Collection("Tari")
	_, err := TaraCollection.Indexes().CreateOne(context.Background(),
		mongo.IndexModel{
			Keys:    bsonx.Doc{{Key: "nume_tara", Value: bsonx.String("text")}},
			Options: options.Index().SetUnique(true),
		})
	if err != nil {
		log.Fatalf("something went wrong: %+v", err)
	}

	// Create collection
	command = bson.D{{Key: "create", Value: "Orase"}}
	if err := DB.RunCommand(Context, command).Decode(&result); err != nil {
		log.Fatal(err)
	}

	// Mark unique (id_tara, nume_oras)
	OraseCollection = DB.Collection("Orase")
	_, err = OraseCollection.Indexes().CreateOne(context.Background(),
		mongo.IndexModel{
			Keys: bsonx.Doc{
				{Key: "nume_oras", Value: bsonx.String("text")},
				{Key: "id_tara", Value: bsonx.Int32(1)},
			},
			Options: options.Index().SetUnique(true),
		})
	if err != nil {
		log.Fatalf("something went wrong: %+v", err)
	}

	// Create collection
	command = bson.D{{Key: "create", Value: "Temperaturi"}}
	if err := DB.RunCommand(Context, command).Decode(&result); err != nil {
		log.Fatal(err)
	}

	// Create unique
	TemperaturiCollection = DB.Collection("Temperaturi")
	_, err = TemperaturiCollection.Indexes().CreateOne(context.Background(),
		mongo.IndexModel{
			Keys: bsonx.Doc{
				{Key: "id_oras", Value: bsonx.Int32(1)},
				{Key: "timestamp", Value: bsonx.Int64(1)},
			},
			Options: options.Index().SetUnique(true),
		})
	if err != nil {
		log.Fatalf("something went wrong: %+v", err)
	}

	// Create id_counter, used for incrementing collection ids
	command = bson.D{{Key: "create", Value: "ID_COUNTERS"}}
	if err := DB.RunCommand(Context, command).Decode(&result); err != nil {
		log.Fatal(err)
	}
	CountersCollection = DB.Collection("ID_COUNTERS")
	var init_id_counter models.ID_COUNTERS
	init_id_counter.Id_orase = 0
	init_id_counter.Id_tari = 0
	init_id_counter.Id_temperaturi = 0
	_, err = CountersCollection.InsertOne(Context, init_id_counter)
	if err != nil {
		fmt.Println("Database id counters init fail")
	}

}

func ConnectToDatabase() *mongo.Database {
	conn_string := os.Getenv("MONGODB_CONNSTRING_ENV")
	db_name := os.Getenv("MONGODB_DBNAME_ENV")
	fmt.Println("MONOGODB_CONNSTRING_ENV: ", conn_string)
	fmt.Println("MONGODB_DBNAME_ENV: ", db_name)
	Context = context.TODO()
	// Unmarshall inner interface{} objects as bson.M
	// tM := reflect.TypeOf(bson.M{})
	// reg := bson.NewRegistryBuilder().RegisterTypeMapEntry(bsontype.EmbeddedDocument, tM).Build()
	client, err := mongo.Connect(Context, options.Client().ApplyURI(conn_string))
	if err != nil {
		fmt.Println("Error connecting")
		fmt.Println("MONOGODB_CONNSTRING_ENV: ", conn_string)
		fmt.Println("MONGODB_DBNAME_ENV: ", db_name)
		panic(err)
	}
	fmt.Println("Connected to DB")
	DB = client.Database(db_name)

	// TEMPORARY DROP
	client.Database("tema_sprc_02").Drop(Context)
	// Database init / Create collections
	db_list, err := client.ListDatabases(context.Background(), bson.D{{Key: "name", Value: "tema_sprc_02"}})
	if err != nil {
		log.Fatal(err)
	}
	if db_list.TotalSize == 0 {
		fmt.Println("Init Database")
		InitDatabase()
	} else {
		TaraCollection = DB.Collection("Tari")
		OraseCollection = DB.Collection("Orase")
		TemperaturiCollection = DB.Collection("Temperaturi")
		CountersCollection = DB.Collection("ID_COUNTERS")
		fmt.Println(TaraCollection)
		fmt.Println("Database already init")
	}

	return DB
}
