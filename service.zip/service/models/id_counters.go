package models

type ID_COUNTERS struct {
	Id_tari        int `bson:"id_tari" json:"id_tari"`
	Id_orase       int `bson:"id_orase" json:"id_orase"`
	Id_temperaturi int `bson:"id_temperaturi" json:"id_temperaturi"`
}
